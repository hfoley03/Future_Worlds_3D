# -*- coding: utf-8 -*-

__version__ = "1.1"

from .world3 import World3, hello_world3
