# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt

from pyworld3 import World3
from pyworld3.utils import plot_world_variables
from numpy import savetxt

params = {'lines.linewidth': '3','axes.labelsize' : '12', 'xtick.labelsize' : '10', 'ytick.labelsize' : '10', 'figure.autolayout' : 'True'}
plt.rcParams.update(params)

"""
Choose Scenario:
    1: A Referenz Point
    2: More Abundant Nonrenewable Resources
    3: More Abundant Nonrenewable Resources and pollution control
    
Disclaimer: Scenario 2 and 3 do not match the scenarios of "Limits to Growth: The 30-year update", because some parameters were changed wich are not descriped.  
"""
scenario = 1
def plot_scenario(scenario = 1):
    if scenario == 1:

        world3 = World3(dt = 1, pyear = 4000)
        world3.init_world3_constants()
        world3.init_world3_variables()
        world3.set_world3_table_functions()
        world3.set_world3_delay_functions()
        world3.run_world3(fast=False)
        """
        plot_world_variables(world3.time,
                        [world3.nrfr, world3.io, world3.f, world3.pop,
                        world3.ppolx],
                        ["NRFR", "IO", "F", "POP", "PPOLX"],
                        [[0, 1.975], [0, 4e12], [0, 5.8e12], [0, 12e9], [0, 40]],
                        #img_background="./img/fig 4-1-1.png",
                        figsize=(7, 5),
                        title="World3 Reference Run, 2004 Scenario 1")
        
        plot_world_variables(world3.time,
                        [world3.le, world3.fpc, world3.sopc, world3.ciopc],
                        ["LE", "FPC", "SOPC", "CIOPC"],
                        [[0, 90], [0,1000],[0,970], [0, 250]],
                        #img_background="./img/fig 4-1-2.png",
                        figsize=(7, 5),
                        title="World3 Reference Run - Material standard of living, 2004 Scenario 1")
        """ 
        
        plot_world_variables(world3.time,
                        [world3.ef, world3.hwi],
                        ["EF", "HWI"],
                        [[0, 4], [0,1]],
                        #img_background="./img/fig 4-1-3.png",
                        figsize=(7, 5), title=f"World3 Reference Run - Human Wellfare{world3.hwi[-1]} and Footprint, 2004 Scenario 1")
        
        print("Scenario 1, referenz run")
        
    if scenario == 2:
        world3 = World3(dt = 1, pyear = 4000)
        world3.init_world3_constants(nri=2e12)
        world3.init_world3_variables()
        world3.set_world3_table_functions()
        world3.set_world3_delay_functions()
        world3.run_world3(fast=False)
        """
        plot_world_variables(world3.time,
                        [world3.nrfr, world3.io, world3.f, world3.pop,
                        world3.ppolx],
                        ["NRFR", "IO", "F", "POP", "PPOLX"],
                        [[0, 0.9875], [0, 4e12], [0, 5.8e12], [0, 12e9], [0, 40]],
                        #img_background="./img/fig 4-2-1.jpg",
                        figsize=(7, 5),
                        title="World3 More Resources, 2004 Scenario 2")

        plot_world_variables(world3.time,
                        [world3.le, world3.fpc, world3.sopc, world3.ciopc],
                        ["LE", "FPC", "SOPC", "CIOPC"],
                        [[0, 90], [0,1000],[0,970], [0, 250]],
                        #img_background="./img/fig 4-2-2.jpg",
                        figsize=(7, 5),
                        title="World3 More Resources - Material standard of living, 2004 Scenario 2")
        """
        plot_world_variables(world3.time,
                        [world3.ef, world3.hwi],
                        ["EF", "HWI"],
                        [[0, 4], [0,1]],
                        #img_background="./img/fig 4-2-3.jpg",
                        figsize=(7, 5), title="World3 More Resources - Human Wellfare and Footprint, 2004 Scenario 2")
        
        print("Scenario 2: More Resources")
        
    if scenario == 3:
        world3 = World3(dt = 1,pyear_pp_tech = 2002)
        world3.init_world3_constants(nri=2e12)
        world3.init_world3_variables()
        world3.set_world3_table_functions()
        world3.set_world3_delay_functions()
        world3.run_world3(fast=False)
        """
        plot_world_variables(world3.time,
                        [world3.nrfr, world3.io, world3.f, world3.pop,
                        world3.ppolx],
                        ["NRFR", "IO", "F", "POP", "PPOLX"],
                        [[0, 1.975], [0, 4e12], [0, 6e12], [0, 12e9], [0, 40]],
                        #img_background="./img/fig 4-3-1.jpg",
                        figsize=(7, 5),
                        title="World3 More Resources and Pollution Control, 2004 Scenario 3")

        plot_world_variables(world3.time,
                        [world3.le, world3.fpc, world3.sopc, world3.ciopc],
                        ["LE", "FPC", "SOPC", "CIOPC"],
                        [[0, 90], [0,1020],[0,970], [0, 250]],
                        #img_background="./img/fig 4-3-2.jpg",
                        figsize=(7, 5),
                        title="World3 More Resources and Pollution Control - Material standard of living, 2004 Scenario 3")
        """
        plot_world_variables(world3.time,
                        [world3.ef, world3.hwi],
                        ["EF", "HWI"],
                        [[0, 4.2], [0,1]],
                        ##img_background="./img/fig 4-3-3.jpg",
                        figsize=(7, 5), title="World3 More Resources and Pollution Control - Human Wellfare and Footprint, 2004 Scenario 3")
        
        savetxt("./prova3.csv",world3.hwi[:50],fmt='%.3e',delimiter=",")
        print("Scenario 3: More Resources and Pollution Control")
    
    #plt.show(block=(scenario is 3))
    plt.show()
for i in range(1,2):
    plot_scenario(i)
    
