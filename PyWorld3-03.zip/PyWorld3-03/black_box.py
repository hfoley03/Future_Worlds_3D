from pyworld3 import World3
import numpy as np
import mealpy as mp
import argparse

max_HWI=4
HWI = 0
EF = 1

#Objective functions:
#they both create an instance of a World3 object, with the years of implementation of the policies as parameter, 
#and return an average of the last 200 values of either HWI or EF
def estimate_HWI(policy_array=None):

    
    world3 = World3(dt = 1,pyear=policy_array[0], pyear_res_tech =policy_array[1], pyear_pp_tech =policy_array[2],pyear_fcaor =policy_array[3], pyear_y_tech =policy_array[4],
                 iphst=policy_array[5])
    world3.init_world3_constants()
    world3.init_world3_variables()
    world3.set_world3_table_functions()
    world3.set_world3_delay_functions()
    world3.run_world3(fast=False)
    
    return np.average(world3.hwi[-200:])

def estimate_EF(policy_array=None):

    
    world3 = World3(dt = 1,pyear=policy_array[0], pyear_res_tech =policy_array[1], pyear_pp_tech =policy_array[2],pyear_fcaor =policy_array[3], pyear_y_tech =policy_array[4],
                 iphst=policy_array[5])
    world3.init_world3_constants()
    world3.init_world3_variables()
    world3.set_world3_table_functions()
    world3.set_world3_delay_functions()
    world3.run_world3(fast=False)
    
    return np.average(world3.ef[-100:])


if __name__ == '__main__':

    #Parser for command line arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--ef', action='store_const',const="EF",dest="var")
    parser.add_argument('--hwi', action='store_const',const="HWI",dest="var")
    parser.add_argument('--min', action='store_const',const="min",dest="obj")
    parser.add_argument('--max', action='store_const',const="max",dest="obj")
    args = parser.parse_args()
    
    #print(args.var, args.obj)
    
    #problems definition
    problem_dict_HWI = {
        "obj_func": estimate_HWI,
        "bounds": mp.IntegerVar(lb=[1900, ] * 6, ub=[2100, ] * 6,),
        "minmax": args.obj,
    }
    problem_dict_EF = {
        "obj_func": estimate_EF,
        "bounds": mp.IntegerVar(lb=[1900, ] * 6, ub=[2100, ] * 6,),
        "minmax": args.obj,
    }

    print(f"I will {args.obj}imize the {args.var} variable")
    optimizer = mp.GA.BaseGA(epoch=50, pop_size=50, pc=0.85, pm=0.1)
    
    if(args.var =="HWI"):
        optimizer.solve(problem_dict_HWI)
    elif(args.var =="EF"):
        print("here")
        optimizer.solve(problem_dict_EF)
    
    
    print(optimizer.g_best.solution)
    print(optimizer.g_best.target.fitness)

    with open(f"{args.obj}_{args.var}_200yrs.txt","w") as f:
         print(optimizer.g_best.target.fitness,file=f)
         print(optimizer.g_best.solution,file=f)