import matplotlib.pyplot as plt

from pyworld3 import World3
from pyworld3.utils import plot_world_variables
from numpy import savetxt,max, transpose,log
import os
import pandas as pd 

def min_max_normalize(array,max):
    return (array)/(max)

def log_normalize(array,max):
    return log(array)/log(max)

def update_max(array,index):
    if max(array) > max_array[index]:
        max_array[index]=max(array)

#function to be called with each world to update current max
def update_max_array(world3):
    update_max(world3.nrfr,0)
    update_max(world3.io,1)
    update_max(world3.f,2)
    update_max(world3.pop,3)
    update_max(world3.ppolx,4)
    update_max(world3.le,5)
    update_max(world3.fpc,6)
    update_max(world3.sopc,7)
    update_max(world3.ciopc,8)
    update_max(world3.ef,9)
    update_max(world3.hwi,10)

def get_full_array(world3,log=False):
    tmp = [world3.nrfr,world3.io,world3.f,world3.pop,world3.ppolx,world3.le,world3.fpc,world3.sopc,world3.ciopc,world3.ef,world3.hwi]
    ret = [[]]*11
    fun = None
    if log is False:
        normalization_function = min_max_normalize
    else:
        normalization_function =log_normalize
    for i in range(len(tmp)):
        ret[i] = normalization_function(tmp[i],max_array[i])
    
    #replace life expectancy in [0,1] with life expectancy with years
    ret[5] = tmp[5]
    return ret

params = {'lines.linewidth': '3','axes.labelsize' : '12', 'xtick.labelsize' : '10', 'ytick.labelsize' : '10', 'figure.autolayout' : 'True'}
plt.rcParams.update(params)
#base_folder ="/Common_Drive/Documenti/Uni/Magistrale/Creative Computing/Project/Solutions/"
base_folder =os.path.join(os.getcwd,"Solutions")

#parameters of the simulation

#type of normalization
log_normalization = False
normalization_label = "Log" if log_normalization else "MinMax"

policy_titles=["BAU","max_ef_200yrs","max_hwi_200yrs"]

#arrays of solutions(combination of years in which policies are implemented)
policy_arrays= [[4000,4000,4000,4000,4000,1940],[1945,1900,2099,2013,1938, 2049],
[2017,1979,1939,1906,1940,1996]]
#array containing the max values for each variable
max_array= [-1]*11

#array obtained through a previous iteration of update_max_array() on the selected worlds
#max_array = [1.0, 10888002070216.574, 5129082252628.274, 7651944316.432856, 191.89783744095166, 85.43440688603597, 1555.4251701921453, 3474.5347342282735, 1972.3107264271414, 5.524001072789365, 0.8974044147636663]

world_list=[]

#update the max_array
for i in range(len(policy_titles)):
    policy_array = policy_arrays[i]
    world3 = World3(dt = 1,pyear=policy_array[0], pyear_res_tech =policy_array[1], pyear_pp_tech =policy_array[2],pyear_fcaor =policy_array[3], pyear_y_tech =policy_array[4],
                     iphst=policy_array[5])

    world3.init_world3_constants()
    world3.init_world3_variables()
    world3.set_world3_table_functions()
    world3.set_world3_delay_functions()
    world3.run_world3(fast=False)
    update_max_array(world3)
    world_list.append(world3)

#create data 
for i in range(len(policy_titles)):
    path = os.path.join(base_folder,policy_titles[i])
    try:  
        os.mkdir(path)  
    except OSError as error:  
        print(error)   

    world3 = world_list[i]
    full_array = get_full_array(world3,log = log_normalization)
    df = pd.DataFrame(transpose(full_array))
    df.to_csv(os.path.join(path,f"{policy_titles[i]}_data.csv"),index=None,header=["NRFR", "IO", "F", "POP", "PPOLX","LE", "FPC", "SOPC", "CIOPC","EF", "HWI"])
    
    plot_world_variables(world3.time,
                    [world3.nrfr, world3.io, world3.f, world3.pop,
                    world3.ppolx],
                    ["NRFR", "IO", "F", "POP", "PPOLX"],
                    [[0, 1.975], [0, 4e12], [0, 5.8e12], [0, 12e9], [0, 40]],
                    figsize=(7, 5),
                    title=f"World3 {policy_titles[i]}")
    
    #plt.savefig(f"{path}/figure1.jpg")

    
    plot_world_variables(world3.time,
                    [world3.le, world3.fpc, world3.sopc, world3.ciopc],
                    ["LE", "FPC", "SOPC", "CIOPC"],
                    [[0, 90], [0,1000],[0,970], [0, 250]],
                    figsize=(7, 5),
                    title=f"World3 {policy_titles[i]}")

    #plt.savefig(f"{path}/figure2.jpg")

    plot_world_variables(world3.time,
                            [world3.ef, world3.hwi],
                            ["EF", "HWI"],
                            [[0, 4], [0,1]],
                            figsize=(7, 5), title=f"World3 {policy_titles[i]} - Human Welfare and Footprint")
            
    #plt.savefig(f"{path}/figure3.jpg")
    
    plt.show()

